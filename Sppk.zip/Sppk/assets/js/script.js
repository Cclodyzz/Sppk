// Anda dapat menambahkan logika JavaScript di sini jika diperlukan.
console.log("Script JS aktif.");
