<?php
class Penilaian
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function create($penyiar_id, $user_id, $kualitas_suara, $keterampilan_komunikasi, $penguasaan_materi, $kreatifitas, $engagement, $tanggal)
    {
        $stmt = $this->conn->prepare("INSERT INTO penilaian (penyiar_id, user_id, kualitas_suara, keterampilan_komunikasi, penguasaan_materi, kreatifitas, engagement, tanggal) VALUES (:penyiar_id, :user_id, :kualitas_suara, :keterampilan_komunikasi, :penguasaan_materi, :kreatifitas, :engagement, :tanggal)");
        $stmt->bindParam(':penyiar_id', $penyiar_id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':kualitas_suara', $kualitas_suara);
        $stmt->bindParam(':keterampilan_komunikasi', $keterampilan_komunikasi);
        $stmt->bindParam(':penguasaan_materi', $penguasaan_materi);
        $stmt->bindParam(':kreatifitas', $kreatifitas);
        $stmt->bindParam(':engagement', $engagement);
        $stmt->bindParam(':tanggal', $tanggal);
        return $stmt->execute();
    }
}
