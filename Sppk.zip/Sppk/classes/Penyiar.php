<?php
class Penyiar
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function create($nama)
    {
        $stmt = $this->conn->prepare("INSERT INTO penyiar (nama) VALUES (:nama)");
        $stmt->bindParam(':nama', $nama);
        return $stmt->execute();
    }

    public function getAll()
    {
        $stmt = $this->conn->query("SELECT * FROM penyiar");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getBestPenyiar()
    {
        $query = "SELECT p.nama, 
                  AVG(kualitas_suara) as avg_kualitas, 
                  AVG(keterampilan_komunikasi) as avg_komunikasi, 
                  AVG(penguasaan_materi) as avg_materi, 
                  AVG(kreatifitas) as avg_kreatifitas, 
                  AVG(engagement) as avg_engagement
                  FROM penilaian AS pn
                  JOIN penyiar AS p ON pn.penyiar_id = p.id
                  GROUP BY p.id
                  ORDER BY avg_kualitas DESC
                  LIMIT 1";
        return $this->conn->query($query)->fetch(PDO::FETCH_ASSOC);
    }
}
